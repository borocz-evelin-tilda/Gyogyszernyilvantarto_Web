using MHISWebApplication.Controllers;
using MHISWebApplication.Models;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using Xunit;

namespace TestMHISWebAPI
{
    public class UnitTest
    {
        private readonly MHIS_dbContext _context;
        private readonly ExaminationController _controllerEx;
        private readonly DrugController _controllerD;

        public UnitTest()
        {
            _context = new MHIS_dbContext();
            _controllerEx = new ExaminationController(_context);
            _controllerD = new DrugController(_context);
        }

        [Fact]
        public void Add_ValidObjectPassed_ReturnsCreatedResponse()
        {
            // Arrange
            Drug testItem = new Drug()
            {
                drugID = 92,
                isNoPrescription = true,
                ingredient = "...",
                medicinename = "vitamin",
                disease = "problem",

            };
            // Act
            var createdResponse = _controllerD.PostDrug(testItem);
            // Assert
            Assert.NotNull(createdResponse);
        }

        [Fact]
        public void Add_ValidObjectPassed_ReturnsBadRequest()
        {
            // Arrange
            var testItem = new Drug()
            {
                drugID = 98,
                isNoPrescription = true,
                ingredient = "a",
                disease = "problem",
            };
            _controllerD.ModelState.AddModelError("drugID", "Required");
            // Act
            var createdResponse = _controllerD.PostDrug(testItem);
            // Assert
            Assert.NotNull(createdResponse);
        }
    }
}
