﻿using MHISWebApplication.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace MHISWebApplication.Repositories
{
    public class UserRepo : IUserRepo
    {
        #region Connect to database
        Patient _User = new Patient();
        private MHIS_dbContext db;
        public UserRepo(MHIS_dbContext context)
        {
            db = context;
        }
        #endregion

        #region Patients by Username and Password

        
        public async Task<Patient> GetUser(Patient user)
        {
            _User = new Patient();
            var users = db.patient
              .Where(x => x.username == user.username && x.p_password == user.p_password);
            if (users != null && users.Count() > 0)
            {
                _User = users.SingleOrDefault();
            }

            return _User;


        }

        #endregion
    }
}
