﻿using MHISWebApplication.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace MHISWebApplication.Repositories
{
    public interface IUserRepo
    {
        Task<Patient> GetUser(Patient user);
    }
}
