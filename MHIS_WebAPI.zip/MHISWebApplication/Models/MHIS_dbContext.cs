﻿using System;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata;

#nullable disable

namespace MHISWebApplication.Models
{
    public partial class MHIS_dbContext : DbContext
    {
        public MHIS_dbContext()
        {
        }

        public MHIS_dbContext(DbContextOptions<MHIS_dbContext> options)
            : base(options)
        {
        }

        public virtual DbSet<Doctor> doctor { get; set; }
        public virtual DbSet<Drug> drug { get; set; }
        public virtual DbSet<Examination> examination { get; set; }
        public virtual DbSet<Illness> illness { get; set; }
        public virtual DbSet<Patient> patient { get; set; }
        public virtual DbSet<Sensitivity> sensitivity { get; set; }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            if (!optionsBuilder.IsConfigured)
            {
#warning To protect potentially sensitive information in your connection string, you should move it out of source code. You can avoid scaffolding the connection string by using the Name= syntax to read it from configuration - see https://go.microsoft.com/fwlink/?linkid=2131148. For more guidance on storing connection strings, see http://go.microsoft.com/fwlink/?LinkId=723263.
                optionsBuilder.UseMySql("server=localhost;user=root;database=mhis_db", Microsoft.EntityFrameworkCore.ServerVersion.Parse("10.4.6-mariadb"));
            }
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.HasCharSet("utf8")
                .UseCollation("utf8_hungarian_ci");

            modelBuilder.Entity<Doctor>(entity =>
            {
                entity.HasCharSet("utf8mb4")
                    .UseCollation("utf8mb4_hungarian_ci");
            });

            modelBuilder.Entity<Drug>(entity =>
            {
                entity.HasCharSet("utf8mb4")
                    .UseCollation("utf8mb4_hungarian_ci");
            });

            modelBuilder.Entity<Examination>(entity =>
            {
                entity.HasCharSet("utf8mb4")
                    .UseCollation("utf8mb4_hungarian_ci");

                entity.HasOne(d => d.doctor)
                    .WithMany(p => p.examination)
                    .HasForeignKey(d => d.doctorID)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("examination_ibfk_3");

                entity.HasOne(d => d.illness)
                    .WithMany(p => p.examination)
                    .HasForeignKey(d => d.illnessID)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("examination_ibfk_2");

                entity.HasOne(d => d.tajNavigation)
                    .WithMany(p => p.examination)
                    .HasForeignKey(d => d.taj)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("examination_ibfk_4");
            });

            modelBuilder.Entity<Illness>(entity =>
            {
                entity.HasCharSet("utf8mb4")
                    .UseCollation("utf8mb4_hungarian_ci");
            });

            modelBuilder.Entity<Patient>(entity =>
            {
                entity.HasKey(e => e.taj)
                    .HasName("PRIMARY");

                entity.HasCharSet("utf8mb4")
                    .UseCollation("utf8mb4_hungarian_ci");
            });

            modelBuilder.Entity<Sensitivity>(entity =>
            {
                entity.HasCharSet("utf8mb4")
                    .UseCollation("utf8mb4_hungarian_ci");

                entity.HasOne(d => d.drug)
                    .WithMany()
                    .HasForeignKey(d => d.drugID)
                    .HasConstraintName("sensitivity_ibfk_2");

                entity.HasOne(d => d.tajNavigation)
                    .WithMany()
                    .HasForeignKey(d => d.taj)
                    .HasConstraintName("sensitivity_ibfk_1");
            });

            OnModelCreatingPartial(modelBuilder);
        }

        partial void OnModelCreatingPartial(ModelBuilder modelBuilder);
    }
}
