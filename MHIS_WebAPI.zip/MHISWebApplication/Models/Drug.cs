﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

#nullable disable

namespace MHISWebApplication.Models
{
    public partial class Drug
    {
        [Key]
        [Column(TypeName = "int(11)")]
        public int drugID { get; set; }
        public bool isNoPrescription { get; set; }
        [Required]
        [Column(TypeName = "text")]
        public string ingredient { get; set; }
        [Required]
        [StringLength(30)]
        public string medicinename { get; set; }
        [Required]
        [StringLength(255)]
        public string disease { get; set; }
    }
}
