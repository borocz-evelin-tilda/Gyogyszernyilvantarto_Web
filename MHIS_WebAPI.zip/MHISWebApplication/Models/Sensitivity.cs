﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

#nullable disable

namespace MHISWebApplication.Models
{
    [Keyless]
    [Index(nameof(drugID), Name = "gyogyszer_az")]
    [Index(nameof(taj), Name = "taj")]
    public partial class Sensitivity
    {
        [Column(TypeName = "int(11)")]
        public int? taj { get; set; }
        [Column(TypeName = "int(11)")]
        public int? drugID { get; set; }

        [ForeignKey(nameof(drugID))]
        public virtual Drug drug { get; set; }
        [ForeignKey(nameof(taj))]
        public virtual Patient tajNavigation { get; set; }
    }
}
