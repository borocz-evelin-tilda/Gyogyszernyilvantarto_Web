﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

#nullable disable

namespace MHISWebApplication.Models
{
    public partial class Illness
    {
        public Illness()
        {
            examination = new HashSet<Examination>();
        }

        [Key]
        [Column(TypeName = "int(11)")]
        public int illnessID { get; set; }
        [Required]
        [StringLength(100)]
        public string symptom { get; set; }
        public bool isInfectious { get; set; }
        [Required]
        [StringLength(30)]
        public string i_name { get; set; }

        [InverseProperty("illness")]
        public virtual ICollection<Examination> examination { get; set; }
    }
}
