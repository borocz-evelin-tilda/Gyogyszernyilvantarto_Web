﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

#nullable disable

namespace MHISWebApplication.Models
{
    [Index(nameof(illnessID), Name = "betegseg_az")]
    [Index(nameof(doctorID), Name = "orvos_az")]
    [Index(nameof(taj), Name = "taj")]
    public partial class Examination
    {
        [Key]
        [Column(TypeName = "int(11)")]
        public int examinationID { get; set; }
        [Column(TypeName = "int(11)")]
        public int illnessID { get; set; }
        [Column(TypeName = "date")]
        public DateTime date { get; set; }
        [Required]
        [StringLength(30)]
        public string medicine { get; set; }
        [Column(TypeName = "text")]
        public string diagnosis { get; set; }
        [Column(TypeName = "int(11)")]
        public int dosage { get; set; }
        [Column(TypeName = "int(11)")]
        public int medication_time_interval { get; set; }
        [Column(TypeName = "int(11)")]
        public int taj { get; set; }
        [Column(TypeName = "int(11)")]
        public int doctorID { get; set; }

        [ForeignKey(nameof(doctorID))]
        [InverseProperty("examination")]
        public virtual Doctor doctor { get; set; }
        [ForeignKey(nameof(illnessID))]
        [InverseProperty("examination")]
        public virtual Illness illness { get; set; }
        [ForeignKey(nameof(taj))]
        [InverseProperty(nameof(Patient.examination))]
        public virtual Patient tajNavigation { get; set; }
    }
}
