﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

#nullable disable

namespace MHISWebApplication.Models
{
    [Index(nameof(p_email), Name = "email", IsUnique = true)]
    [Index(nameof(p_password), Name = "p_jelszo", IsUnique = true)]
    public partial class Patient
    {
        public Patient()
        {
            examination = new HashSet<Examination>();
        }

        [Key]
        [Column(TypeName = "int(11)")]
        public int taj { get; set; }
        [Required]
        [StringLength(20)]
        public string username { get; set; }
        [Required]
        [StringLength(30)]
        public string p_name { get; set; }
        [Required]
        [StringLength(50)]
        public string p_address { get; set; }
        [Column(TypeName = "date")]
        public DateTime p_birthday { get; set; }
        [Required]
        [StringLength(100)]
        public string p_birthplace { get; set; }
        [Required]
        [StringLength(100)]
        public string allergy { get; set; }
        [Required]
        [StringLength(11)]
        public string p_password { get; set; }
        [Required]
        [StringLength(50)]
        public string p_email { get; set; }

        [InverseProperty("tajNavigation")]
        public virtual ICollection<Examination> examination { get; set; }
    }
}
