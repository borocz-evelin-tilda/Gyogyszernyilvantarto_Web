﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

#nullable disable

namespace MHISWebApplication.Models
{
    [Index(nameof(d_email), Name = "email", IsUnique = true)]
    [Index(nameof(d_password), Name = "jelszo", IsUnique = true)]
    public partial class Doctor
    {
        public Doctor()
        {
            examination = new HashSet<Examination>();
        }

        [Required]
        [StringLength(30)]
        public string d_name { get; set; }
        [Key]
        [Column(TypeName = "int(11)")]
        public int doctorID { get; set; }
        [Column(TypeName = "date")]
        public DateTime d_birthday { get; set; }
        [Required]
        [StringLength(30)]
        public string d_birthplace { get; set; }
        [Required]
        [StringLength(50)]
        public string office { get; set; }
        [Required]
        [StringLength(30)]
        public string specialization { get; set; }
        [Required]
        [StringLength(10)]
        public string d_password { get; set; }
        [Required]
        [StringLength(50)]
        public string d_email { get; set; }

        [InverseProperty("doctor")]
        public virtual ICollection<Examination> examination { get; set; }
    }
}
