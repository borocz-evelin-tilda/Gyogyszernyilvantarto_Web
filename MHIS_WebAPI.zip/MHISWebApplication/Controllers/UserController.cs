﻿
using MHISWebApplication.Models;
using MHISWebApplication.Repositories;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Net;
using System.Threading.Tasks;

namespace MHISWebApplication.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class UserController : ControllerBase
    {
        #region Connect to database
        
        private MHIS_dbContext db;
        IUserRepo _oUserRepo = null;
        public UserController(MHIS_dbContext context, IUserRepo oUserRepo)
        {
            
            db = context;
            _oUserRepo = oUserRepo;
        }
        #endregion

        #region Log in

        [HttpGet]
        [Route("signin/{username}/{password}")]
        public async Task<IActionResult> Signin(string username, string password)
        {
            try
            {
                Patient model = new Patient()
                {
                    username = username,
                    p_password = password
                };
                var user = await AuthenticationUser(model);
                if (user.taj== 0) return StatusCode((int)HttpStatusCode.NotFound, "Nincs ilyen felhasználó!");
                
                return Ok(user);
            }
            catch (Exception ex)
            {
                return StatusCode((int)HttpStatusCode.InternalServerError, ex.Message);
            }
        }

        #endregion

        #region Authenticate user
        private async Task<Patient> AuthenticationUser(Patient user)
        {
            return await _oUserRepo.GetUser(user);
        }
        #endregion
    }
}
