﻿
using MHISWebApplication.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;

using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace MHISWebApplication.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class DrugController : ControllerBase
    {
        #region Connect to database
        
        private MHIS_dbContext db;
        public DrugController(MHIS_dbContext context)
        {
            db = context;
        }
        #endregion

        #region drug by name

        #region drugs

        [HttpGet]
        public async Task<List<Drug>> GetDrugs()
        {
            return await db.drug.ToListAsync();
        }
        #endregion
        [HttpGet("get-name/{item}")]
        public async Task<List<Drug>> GetDrug(string item)
        {
            return await db.drug.Where(x => x.medicinename == item).ToListAsync();
        }
        #endregion

        #region drug by id

        [HttpGet("get-id/{id}")]
        public async Task<ActionResult<Drug>> GetDrugId(int id)
        {
            return Ok(await db.drug.Where(x => x.drugID == id).ToListAsync());
        }
        #endregion

        #region Drug already exsits?
        private bool DrugExists(string item, int id)
        {
            return db.drug.Any(x => x.medicinename == item || x.drugID == id);
        }
        #endregion

        #region  Post drug
        [HttpPost("post")]
        public async Task<ActionResult<Drug>> PostDrug(Drug med)
        {
            db.drug.Add(med);
            await db.SaveChangesAsync();
            return CreatedAtAction("GetDrugId", new {  id = med.drugID }, med);
        }
        #endregion

        #region delete
        [HttpDelete("delete/{id}")]
        public async Task<IActionResult> DeleteDrug(int id)
        {
            var item = await db.drug.FindAsync(id);
            if (item == null)
            {
                return NotFound();
            }

            db.drug.Remove(item);
            await db.SaveChangesAsync();

            return NoContent();
        }
        #endregion


    }
}
