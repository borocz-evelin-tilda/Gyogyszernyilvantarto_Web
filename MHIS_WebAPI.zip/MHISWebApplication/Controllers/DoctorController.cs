﻿
using MHISWebApplication.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace MHISWebApplication.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class DoctorController : ControllerBase
    {
        #region Connect to database
        //private mhis_dbContext db = new mhis_dbContext();
        private MHIS_dbContext db;
        public DoctorController(MHIS_dbContext context)
        {
            db = context;
        }
        #endregion

        #region All doctors


        [HttpGet("get-all")]
        public IEnumerable<Doctor> GetAll()
        {
            /*var doctors = db.doctor;//.ToListAsync();
            if (doctors==null)
            {
                return NotFound();
            }
            return Ok(doctors);*/
            var doctors = db.doctor;
            return doctors;
        }
        #endregion

    }
}
