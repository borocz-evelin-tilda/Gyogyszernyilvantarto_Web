﻿
using MHISWebApplication.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace MHISWebApplication.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class PatientController : ControllerBase
    {
        #region Connect to database
        private MHIS_dbContext db;
        public PatientController(MHIS_dbContext context)
        {
            db = context;
        }
        #endregion

        #region Patient
        
        
        [HttpGet("get-id/{id}")]
        public IActionResult GetByTaj(int id)
        {
        
            return Ok(db.patient.Where(x => x.taj == id).ToList());
        }
        #endregion

      
    }
}
